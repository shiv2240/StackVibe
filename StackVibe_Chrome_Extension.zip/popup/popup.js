/**
 * StackVibe - Chrome Extension Popup Main Controller
 * Advanced UIDrop Feature Integration: AI target selection, Component Blueprints, Design Mix, and Snap Library Grid.
 */

document.addEventListener("DOMContentLoaded", async () => {
  // Initialize Auth & Storage
  const auth = new AuthManager();
  await auth.init();

  let currentScanData = {
    url: "",
    title: "",
    techStack: [],
    designSpec: {},
  };

  let selectedAiTarget = "claude";
  let outputFormatMode = "prompt";
  let componentBlueprints = [];

  // DOM Elements
  const themeToggleBtn = document.getElementById("themeToggleBtn");

  // Initialize Theme (Default to light)
  let currentTheme = "light";
  const savedTheme = await StorageUtil.get("stackvibe_theme");
  if (savedTheme) {
    currentTheme = savedTheme;
  }
  document.documentElement.setAttribute("data-theme", currentTheme);
  if (themeToggleBtn) themeToggleBtn.dataset.theme = currentTheme;

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener("click", async () => {
      currentTheme = currentTheme === "light" ? "dark" : "light";
      document.documentElement.setAttribute("data-theme", currentTheme);
      themeToggleBtn.dataset.theme = currentTheme;
      await StorageUtil.set("stackvibe_theme", currentTheme);
      showToast(`Switched to ${currentTheme} mode`);
    });
  }

  const authBtn = document.getElementById("authBtn");
  const userBtnLabel = document.getElementById("userBtnLabel");
  const authBanner = document.getElementById("authBanner");
  const bannerSignUpBtn = document.getElementById("bannerSignUpBtn");

  const siteTitle = document.getElementById("siteTitle");
  const siteUrl = document.getElementById("siteUrl");
  const rescanBtn = document.getElementById("rescanBtn");

  const tabBtns = document.querySelectorAll(".nav-icon-btn");
  const tabPanes = document.querySelectorAll(".tab-pane");

  const aiTargetCards = document.querySelectorAll(".ai-target-card");
  const fmtToggleBtns = document.querySelectorAll(".fmt-toggle-btn");
  const aiTargetTitle = document.getElementById("aiTargetTitle");
  const aiPromptPreview = document.getElementById("aiPromptPreview");
  const copyAiPromptBtn = document.getElementById("copyAiPromptBtn");

  const componentsGrid = document.getElementById("componentsGrid");
  const downloadBlueprintsBtn = document.getElementById(
    "downloadBlueprintsBtn",
  );

  const mixHeroSelect = document.getElementById("mixHeroSelect");
  const mixNavSelect = document.getElementById("mixNavSelect");
  const mixButtonSelect = document.getElementById("mixButtonSelect");
  const copyMixPromptBtn = document.getElementById("copyMixPromptBtn");
  const mixPromptPreview = document.getElementById("mixPromptPreview");

  const techStackList = document.getElementById("techStackList");
  const stackCountBadge = document.getElementById("stackCountBadge");

  const colorSwatches = document.getElementById("colorSwatches");
  const typographyBox = document.getElementById("typographyBox");
  const tokensBox = document.getElementById("tokensBox");
  const copyMarkdownBtn = document.getElementById("copyMarkdownBtn");

  const snapLibraryGrid = document.getElementById("snapLibraryGrid");
  const librarySearchInput = document.getElementById("librarySearchInput");
  const clearHistoryBtn = document.getElementById("clearHistoryBtn");

  const authModal = document.getElementById("authModal");
  const closeAuthModal = document.getElementById("closeAuthModal");
  const modalTabRegister = document.getElementById("modalTabRegister");
  const modalTabLogin = document.getElementById("modalTabLogin");
  const authForm = document.getElementById("authForm");
  const authSubmitBtn = document.getElementById("authSubmitBtn");
  const nameFieldGroup = document.getElementById("nameFieldGroup");
  const roleFieldGroup = document.getElementById("roleFieldGroup");
  const userProfileView = document.getElementById("userProfileView");
  const logoutBtn = document.getElementById("logoutBtn");
  const updateRoleBtn = document.getElementById("updateRoleBtn");
  const editProfileRoleSelect = document.getElementById(
    "editProfileRoleSelect",
  );

  const toast = document.getElementById("toast");

  let isLoginMode = false;

  function updateAuthUI() {
    if (auth.currentUser) {
      userBtnLabel.textContent = auth.currentUser.name;
      authBanner.style.display = "none";
    } else {
      userBtnLabel.textContent = "Account";
      authBanner.style.display = "flex";
    }
  }

  updateAuthUI();

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 2500);
  }

  async function copyToClipboard(text, successMsg = "Copied to clipboard!") {
    try {
      await navigator.clipboard.writeText(text);
      showToast(successMsg);
    } catch (e) {
      showToast("Failed to copy");
    }
  }

  // --- Tab Navigation ---
  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabBtns.forEach((b) => b.classList.remove("active"));
      tabPanes.forEach((p) => p.classList.remove("active"));

      btn.classList.add("active");
      const targetPane = document.getElementById(btn.dataset.tab);
      if (targetPane) targetPane.classList.add("active");

      if (btn.dataset.tab === "tab-history") {
        renderSnapLibrary();
      }
    });
  });

  // --- Perform Page Scan ---
  async function runScan() {
    rescanBtn.classList.add("is-scanning");
    techStackList.innerHTML = `
      <div class="loading-state">
        <div class="spinner"></div>
        <p>Snapping design system & scanning stack...</p>
      </div>
    `;

    if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.query) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (chrome.runtime.lastError) {
          showScanError(chrome.runtime.lastError.message);
          return;
        }

        if (!tabs || tabs.length === 0) {
          showScanError("No active browser tab is available to scan.");
          return;
        }

        const tab = tabs[0];
        currentScanData.url = tab.url || "";
        currentScanData.title = tab.title || "Active Page";

        siteTitle.textContent = currentScanData.title;
        siteUrl.textContent = currentScanData.url;

        chrome.runtime.sendMessage(
          { action: "GET_ACTIVE_TAB_DATA", tabId: tab.id },
          (res) => {
            if (chrome.runtime.lastError) {
              showScanError(chrome.runtime.lastError.message);
              return;
            }

            if (res && res.success) {
              currentScanData.techStack = res.techStack;
              currentScanData.designSpec = res.designSpec || {};
              renderAllPanels({ saveScan: true });
            } else {
              showScanError(
                res?.error || "The active page could not be scanned.",
              );
            }
          },
        );
      });
    } else {
      showScanError("StackVibe scans are available only inside Chrome.");
    }
  }

  function showScanError(message) {
    rescanBtn.classList.remove("is-scanning");
    currentScanData = {
      url: currentScanData.url || "",
      title: currentScanData.title || "Scan unavailable",
      techStack: [],
      designSpec: {},
    };

    siteTitle.textContent = currentScanData.title;
    siteUrl.textContent = currentScanData.url || "No page data";
    techStackList.innerHTML = '<div class="loading-state"><p></p></div>';
    techStackList.querySelector("p").textContent = message;
    stackCountBadge.textContent = "0 Detected";
    colorSwatches.innerHTML = `<p class="panel-desc">No design tokens were extracted.</p>`;
    typographyBox.textContent = "No typography data was extracted.";
    tokensBox.textContent = "No layout tokens were extracted.";
    aiPromptPreview.textContent =
      "Scan a regular website to generate an evidence-based reconstruction prompt.";
    componentsGrid.innerHTML = `<p class="panel-desc">Component blueprints require a successful scan.</p>`;
    showToast(`Scan unavailable: ${message}`);
  }

  async function renderAllPanels({ saveScan = false } = {}) {
    rescanBtn.classList.remove("is-scanning");
    renderAITargetSection();
    renderComponentBlueprints();
    renderDesignMix();
    renderTechStack();
    renderDesignSystem();
    if (saveScan) await auth.saveScan(currentScanData);
  }

  // --- 1. AI Target Section ---
  function renderAITargetSection() {
    aiTargetTitle.textContent = `Formatted ${outputFormatMode} for ${selectedAiTarget.toUpperCase()}`;

    if (outputFormatMode === "system.md") {
      aiPromptPreview.textContent = ExportEngine.toGetDesignMarkdown(
        currentScanData,
        currentScanData.techStack,
        currentScanData.designSpec,
      );
    } else {
      aiPromptPreview.textContent = ExportEngine.toAIPromptForTarget(
        selectedAiTarget,
        currentScanData,
        currentScanData.techStack,
        currentScanData.designSpec,
      );
    }
  }

  aiTargetCards.forEach((card) => {
    card.addEventListener("click", () => {
      aiTargetCards.forEach((c) => c.classList.remove("active"));
      card.classList.add("active");
      selectedAiTarget = card.dataset.ai;
      renderAITargetSection();
    });
  });

  fmtToggleBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      fmtToggleBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      outputFormatMode = btn.dataset.mode;
      renderAITargetSection();
    });
  });

  // --- 2. Standout Component Blueprints ---
  function renderComponentBlueprints() {
    const spec = currentScanData.designSpec || {};
    const source = currentScanData.url || "the scanned page";
    const components = [];
    const escapeHtml = (value) =>
      String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    const addComponent = (title, kind, evidence, previewStyle = "") => {
      const fields = Object.entries(evidence)
        .filter(
          ([, value]) =>
            value !== null &&
            value !== undefined &&
            value !== "" &&
            value !== "none",
        )
        .map(([key, value]) => `${key}: ${value}`);

      if (!fields.length) return;
      components.push({
        title,
        evidence: fields,
        previewStyle,
        prompt: `Rebuild the ${kind} captured from ${source}. Use only this extracted evidence; do not add unobserved content, colors, effects, or interactions.\n\n${fields.map((field) => `- ${field}`).join("\n")}`,
        css: fields.map((field) => `/* ${field} */`).join("\n"),
      });
    };

    if (spec.components?.header) {
      const header = spec.components.header;
      addComponent(
        "Detected header / navigation",
        "header or navigation",
        {
          "Source text": header.label,
          Height: header.height,
          Position: header.position,
          Background: header.backgroundColor,
          "Bottom border": header.borderBottom,
          "Navigation items": header.navItemsCount,
          Padding: header.padding,
        },
        `background:${header.backgroundColor || "transparent"};`,
      );
    }

    if (spec.components?.hero) {
      const hero = spec.components.hero;
      addComponent("Detected hero section", "hero section", {
        "Source text": hero.label,
        Layout: hero.hasTwoColumns ? "two-column" : "single-column",
        Heading: hero.headingText,
        "Call to action": hero.ctaText,
        Padding: hero.padding,
      });
    }

    (spec.components?.buttons || []).forEach((button, index) => {
      addComponent(
        `Detected button ${index + 1}`,
        "button",
        {
          Label: button.label,
          Height: button.height,
          Background: button.backgroundColor,
          "Text color": button.color,
          "Border radius": button.borderRadius,
          "Font weight": button.fontWeight,
          "Font size": button.fontSize,
          Padding: button.padding,
        },
        `background:${button.backgroundColor || "transparent"};color:${button.color || "inherit"};border-radius:${button.borderRadius || "0"};`,
      );
    });

    (spec.components?.cards || []).forEach((card, index) => {
      addComponent(
        `Detected card ${index + 1}`,
        "card surface",
        {
          "Source text": card.label,
          Background: card.backgroundColor,
          "Border radius": card.borderRadius,
          Border: card.border,
          Shadow: card.shadow,
          Padding: card.padding,
        },
        `background:${card.backgroundColor || "transparent"};border-radius:${card.borderRadius || "0"};`,
      );
    });

    componentBlueprints = components;
    downloadBlueprintsBtn.disabled = components.length === 0;

    if (!components.length) {
      componentsGrid.innerHTML = `<p class="panel-desc">No page components were detected. Scan a regular website to generate evidence-based blueprints.</p>`;
      return;
    }

    componentsGrid.innerHTML = components
      .map(
        (c) => `
      <div class="comp-card">
        <div class="comp-preview" style="${c.previewStyle}">${c.title}</div>
        <span class="comp-title">${c.title}</span>
        <div class="comp-evidence">${c.evidence.map((item) => `<code>${escapeHtml(item)}</code>`).join("")}</div>
        <div class="comp-actions">
          <button class="btn-xs copy-comp-btn" data-prompt="${encodeURIComponent(c.prompt)}">Copy Prompt</button>
          <button class="btn-xs copy-css-btn" data-css="${encodeURIComponent(c.css)}">Copy Evidence</button>
        </div>
      </div>
    `,
      )
      .join("");

    document.querySelectorAll(".copy-comp-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const prompt = decodeURIComponent(btn.dataset.prompt);
        copyToClipboard(prompt, "Component prompt copied!");
      });
    });

    document.querySelectorAll(".copy-css-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        copyToClipboard(
          decodeURIComponent(btn.dataset.css),
          "Component evidence copied!",
        );
      });
    });
  }

  function downloadAllBlueprints() {
    if (!componentBlueprints.length) {
      showToast("Scan a page before downloading blueprints.");
      return;
    }

    const source = currentScanData.url || "Unknown source";
    const markdown = [
      `# ${currentScanData.title || "StackVibe"} — Component Blueprints`,
      "",
      `Source: ${source}`,
      `Exported: ${new Date().toISOString()}`,
      "",
      ...componentBlueprints.flatMap((component, index) => [
        `## ${index + 1}. ${component.title}`,
        "",
        "### Extracted evidence",
        ...component.evidence.map((item) => `- ${item}`),
        "",
        "### Reconstruction prompt",
        "```text",
        component.prompt,
        "```",
        "",
      ]),
    ].join("\n");
    const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
    const downloadUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const filename = (currentScanData.title || "stackvibe")
      .replace(/[^a-z0-9]+/gi, "-")
      .replace(/(^-|-$)/g, "")
      .toLowerCase();

    link.href = downloadUrl;
    link.download = `${filename || "stackvibe"}-component-blueprints.md`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
    showToast("All component blueprints downloaded!");
  }

  downloadBlueprintsBtn.addEventListener("click", downloadAllBlueprints);

  // --- 3. Design Mix ---
  function renderDesignMix() {
    const config = {
      hero: mixHeroSelect.value,
      nav: mixNavSelect.value,
      button: mixButtonSelect.value,
      card: "airbnb.com",
    };

    const combinedPrompt = ExportEngine.toDesignMixPrompt(config);
    mixPromptPreview.textContent = combinedPrompt;
  }

  mixHeroSelect.addEventListener("change", renderDesignMix);
  mixNavSelect.addEventListener("change", renderDesignMix);
  mixButtonSelect.addEventListener("change", renderDesignMix);

  copyMixPromptBtn.addEventListener("click", () => {
    copyToClipboard(
      mixPromptPreview.textContent,
      "Combined Design Mix prompt copied!",
    );
  });

  // --- 4. Tech Stack ---
  function renderTechStack() {
    const stack = currentScanData.techStack;
    stackCountBadge.textContent = `${stack.length} Detected`;

    if (stack.length === 0) {
      techStackList.innerHTML = `<p class="panel-desc">No technology signatures were detected on this page.</p>`;
      return;
    }

    techStackList.innerHTML = stack
      .map(
        (item) => `
      <div class="stack-card">
        <div class="stack-icon" style="color: ${item.color}">${item.icon}</div>
        <div class="stack-meta">
          <div class="stack-title-row">
            <span class="stack-name">${item.name}</span>
            <span class="category-tag">${item.category}</span>
          </div>
          <p class="stack-desc">${item.description}</p>
        </div>
      </div>
    `,
      )
      .join("");
  }

  // --- 5. Design Spec ---
  function renderDesignSystem() {
    const spec = currentScanData.designSpec;

    colorSwatches.innerHTML = (spec.colors || [])
      .map(
        (c) => `
      <div class="swatch-card">
        <div class="swatch-color" style="background-color: ${c.hex};"></div>
        <div class="swatch-meta">
          <span class="swatch-hex">${c.hex}</span>
          <span class="swatch-role">${c.role || "Token"}</span>
        </div>
      </div>
    `,
      )
      .join("");

    const typo = spec.typography || {};
    typographyBox.innerHTML = `
      <div><strong>Font Family:</strong> <code>${typo.fontFamily || "Inter"}</code></div>
      <div><strong>Heading:</strong> ${typo.h1Size || "36px"} (${typo.h1Weight || "700"})</div>
      <div><strong>Body:</strong> ${typo.bodySize || "16px"} (${typo.bodyWeight || "400"})</div>
    `;

    const rad = spec.radius || {};
    tokensBox.innerHTML = `
      <div class="token-item">
        <span>Radius Sm:</span>
        <code>${rad.sm || "4px"}</code>
      </div>
      <div class="token-item">
        <span>Radius Md:</span>
        <code>${rad.md || "8px"}</code>
      </div>
      <div class="token-item">
        <span>Background:</span>
        <code>${spec.background || "#0F172A"}</code>
      </div>
    `;
  }

  // --- 6. Snap Library Grid (Visual Snap Cards) ---
  function renderSnapLibrary(query = "") {
    const scans = auth.savedScans || [];
    const filtered = scans.filter(
      (s) =>
        s.title.toLowerCase().includes(query.toLowerCase()) ||
        s.url.toLowerCase().includes(query.toLowerCase()),
    );

    if (filtered.length === 0) {
      snapLibraryGrid.innerHTML = `<p class="panel-desc">No snaps found in library.</p>`;
      return;
    }

    const gradients = [
      "linear-gradient(135deg, #6366F1, #8B5CF6)",
      "linear-gradient(135deg, #10B981, #059669)",
      "linear-gradient(135deg, #F59E0B, #D97706)",
      "linear-gradient(135deg, #EC4899, #DB2777)",
      "linear-gradient(135deg, #3B82F6, #1D4ED8)",
    ];

    snapLibraryGrid.innerHTML = filtered
      .map((item, idx) => {
        const gradient = gradients[idx % gradients.length];
        const colors = item.designSpec?.colors || [
          { hex: "#6366F1" },
          { hex: "#10B981" },
          { hex: "#0F172A" },
        ];

        return `
        <div class="snap-card load-snap-item" data-id="${item.id}">
          <div class="snap-card-banner" style="background: ${gradient}">
            ${item.title.split(" ")[0]}
          </div>
          <div class="snap-card-body">
            <span class="snap-card-title">${item.title}</span>
            <span class="snap-card-domain">${item.url}</span>
            <div class="snap-card-colors">
              ${colors
                .slice(0, 4)
                .map(
                  (c) =>
                    `<div class="snap-mini-swatch" style="background:${c.hex}"></div>`,
                )
                .join("")}
            </div>
            <div class="snap-card-actions">
              <button class="btn-xs copy-hex-btn" data-hex="${colors[0]?.hex || "#6366F1"}">Copy hex</button>
              <button class="btn-xs delete-snap-btn" data-id="${item.id}">Delete</button>
            </div>
          </div>
        </div>
      `;
      })
      .join("");

    // Listeners
    document.querySelectorAll(".load-snap-item").forEach((card) => {
      card.addEventListener("click", (e) => {
        if (
          e.target.classList.contains("copy-hex-btn") ||
          e.target.classList.contains("delete-snap-btn")
        )
          return;
        const id = card.dataset.id;
        const savedItem = auth.savedScans.find((s) => s.id === id);
        if (savedItem) {
          currentScanData = {
            url: savedItem.url,
            title: savedItem.title,
            techStack: savedItem.techStack || [],
            designSpec: savedItem.designSpec || {},
          };
          siteTitle.textContent = currentScanData.title;
          siteUrl.textContent = currentScanData.url;
          renderAllPanels();
          showToast(`Loaded ${savedItem.title}`);

          // Switch to AI tab
          tabBtns.forEach((b) => b.classList.remove("active"));
          tabPanes.forEach((p) => p.classList.remove("active"));
          document.querySelector('[data-tab="tab-ai"]').classList.add("active");
          document.getElementById("tab-ai").classList.add("active");
        }
      });
    });

    document.querySelectorAll(".copy-hex-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        copyToClipboard(btn.dataset.hex, "Primary HEX copied!");
      });
    });

    document.querySelectorAll(".delete-snap-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        await auth.deleteScan(btn.dataset.id);
        renderSnapLibrary();
        showToast("Snap deleted");
      });
    });
  }

  librarySearchInput.addEventListener("input", (e) => {
    renderSnapLibrary(e.target.value);
  });

  clearHistoryBtn.addEventListener("click", async () => {
    await auth.clearAllScans();
    renderSnapLibrary();
    showToast("Snap library cleared");
  });

  copyAiPromptBtn.addEventListener("click", () => {
    copyToClipboard(aiPromptPreview.textContent, "Schema / AI prompt copied!");
  });

  copyMarkdownBtn.addEventListener("click", () => {
    const md = ExportEngine.toGetDesignMarkdown(
      currentScanData,
      currentScanData.techStack,
      currentScanData.designSpec,
    );
    copyToClipboard(md, "Markdown design spec copied!");
  });

  rescanBtn.addEventListener("click", () => {
    runScan();
  });

  // Auth Modal
  function openAuthModal() {
    if (auth.currentUser) {
      authForm.style.display = "none";
      userProfileView.classList.remove("hidden");
      document.getElementById("profileName").textContent =
        auth.currentUser.name;
      document.getElementById("profileEmail").textContent =
        auth.currentUser.email;
      if (editProfileRoleSelect)
        editProfileRoleSelect.value =
          auth.currentUser.role || "Frontend Engineer";
      document.getElementById("profileAvatar").src = auth.currentUser.avatar;
    } else {
      userProfileView.classList.add("hidden");
      authForm.style.display = "flex";
      setAuthMode(false);
    }
    authModal.classList.add("active");
  }

  function closeAuthModalWindow() {
    authModal.classList.remove("active");
  }

  function setAuthMode(isLogin) {
    isLoginMode = isLogin;
    if (isLogin) {
      modalTabLogin.classList.add("active");
      modalTabRegister.classList.remove("active");
      nameFieldGroup.style.display = "none";
      roleFieldGroup.style.display = "none";
      authSubmitBtn.textContent = "Sign In";
    } else {
      modalTabRegister.classList.add("active");
      modalTabLogin.classList.remove("active");
      nameFieldGroup.style.display = "flex";
      roleFieldGroup.style.display = "flex";
      authSubmitBtn.textContent = "Create Free Account";
    }
  }

  authBtn.addEventListener("click", openAuthModal);
  bannerSignUpBtn.addEventListener("click", openAuthModal);
  closeAuthModal.addEventListener("click", closeAuthModalWindow);

  modalTabLogin.addEventListener("click", () => setAuthMode(true));
  modalTabRegister.addEventListener("click", () => setAuthMode(false));

  authForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("userEmailInput").value;
    const password = document.getElementById("userPasswordInput").value;
    const name = document.getElementById("userNameInput").value;
    const role = document.getElementById("userRoleSelect").value;

    try {
      if (isLoginMode) {
        await auth.login(email, password);
        showToast("Signed in successfully!");
      } else {
        await auth.register(name, email, password, role);
        showToast("Account created!");
      }
      updateAuthUI();
      closeAuthModalWindow();
    } catch (err) {
      showToast(err.message);
    }
  });

  if (updateRoleBtn) {
    updateRoleBtn.addEventListener("click", async () => {
      const selectedRole = editProfileRoleSelect.value;
      await auth.updateRole(selectedRole);
      updateAuthUI();
      showToast(`Role updated to ${selectedRole}!`);
    });
  }

  logoutBtn.addEventListener("click", async () => {
    await auth.logout();
    updateAuthUI();
    closeAuthModalWindow();
    showToast("Signed out");
  });

  runScan();
});
